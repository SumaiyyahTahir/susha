package com.example.susha

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
