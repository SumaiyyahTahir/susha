import 'package:firebase_susha/firebase_susha.dart';

void main() {
}
